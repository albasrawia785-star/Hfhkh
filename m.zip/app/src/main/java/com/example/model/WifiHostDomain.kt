package com.example.model

enum class UserStatus {
    ONLINE,  // 🟢 متصل
    BUSY,    // 🟡 مشغول (في محادثة)
    OFFLINE  // ⚪ غير متصل
}

data class WifiHostDomain(
    val deviceId: String,
    val name: String,
    val phoneModel: String = android.os.Build.MODEL ?: "الهاتف الذكي",
    val androidVersion: String = android.os.Build.VERSION.RELEASE ?: "Android",
    val ipAddress: String,
    val port: Int = 8888,
    val appVersion: String = "1.0.0",
    val status: UserStatus = UserStatus.ONLINE,
    val isFavorite: Boolean = false,
    val lastSeenTimestamp: Long = System.currentTimeMillis()
)
