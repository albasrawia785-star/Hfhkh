package com.example.model

import org.json.JSONObject
import java.util.UUID

data class BluetoothMessage(
    val id: String = UUID.randomUUID().toString(),
    val senderAddress: String,
    val senderName: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toJsonString(): String {
        return JSONObject().apply {
            put("id", id)
            put("senderAddress", senderAddress)
            put("senderName", senderName)
            put("text", text)
            put("timestamp", timestamp)
        }.toString()
    }

    companion object {
        fun jsonToMessage(jsonString: String): BluetoothMessage? {
            return try {
                val json = JSONObject(jsonString)
                BluetoothMessage(
                    id = json.optString("id", UUID.randomUUID().toString()),
                    senderAddress = json.optString("senderAddress", ""),
                    senderName = json.optString("senderName", "Unknown"),
                    text = json.optString("text", ""),
                    timestamp = json.optLong("timestamp", System.currentTimeMillis())
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
