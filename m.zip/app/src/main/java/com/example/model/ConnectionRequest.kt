package com.example.model

data class ConnectionRequest(
    val senderId: String = "",
    val senderName: String,
    val senderPhoneModel: String = "Android Device",
    val senderAddress: String,
    val connectionType: ConnectionType,
    val timestamp: Long = System.currentTimeMillis()
)

enum class OutgoingRequestStatus {
    NONE,
    WAITING,
    ACCEPTED,
    DECLINED,
    BUSY,
    EXPIRED
}
