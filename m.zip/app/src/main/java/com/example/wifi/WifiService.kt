package com.example.wifi

import android.content.Context
import android.util.Log
import com.example.connection.ChatConnection
import com.example.model.BluetoothDeviceDomain
import com.example.model.BluetoothPacket
import com.example.model.ConnectionState
import com.example.model.ConnectionType
import com.example.model.PacketType
import com.example.model.UserStatus
import com.example.model.WifiHostDomain
import com.example.utils.WifiUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.FileReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID

class WifiService(
    private val context: Context
) : ChatConnection {

    private val TAG = "WifiService"
    val TCP_PORT = 8888
    val UDP_PORT = 8889

    private val HANDSHAKE_TOKEN = "WIFI_CHAT_BEACON_V1_APP_TOKEN_8899"

    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _receivedPackets = MutableSharedFlow<BluetoothPacket>(extraBufferCapacity = 128)
    override val receivedPackets: SharedFlow<BluetoothPacket> = _receivedPackets.asSharedFlow()

    private val _isPartnerTyping = MutableStateFlow(false)
    override val isPartnerTyping: StateFlow<Boolean> = _isPartnerTyping.asStateFlow()

    private val _discoveredHosts = MutableStateFlow<List<WifiHostDomain>>(emptyList())
    val discoveredHosts: StateFlow<List<WifiHostDomain>> = _discoveredHosts.asStateFlow()

    private val _isDiscovering = MutableStateFlow(false)
    val isDiscovering: StateFlow<Boolean> = _isDiscovering.asStateFlow()

    private val myDeviceId = UUID.randomUUID().toString().take(8)
    private val favoriteIps = mutableSetOf<String>()

    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null
    private var outputStream: OutputStream? = null

    private var udpBeaconSocket: DatagramSocket? = null

    private var lastConnectedIp: String? = null
    private var lastConnectedName: String? = null
    private var shouldAutoReconnect = false

    init {
        startBackgroundService()
    }

    fun startBackgroundService() {
        serviceScope.launch(Dispatchers.IO) {
            startTcpListener()
            startBeaconBroadcaster()
            startBeaconReceiver()
            startCleanupTask()
        }
    }

    private fun getMyUserStatus(): UserStatus {
        return if (_connectionState.value is ConnectionState.Connected) {
            UserStatus.BUSY
        } else {
            UserStatus.ONLINE
        }
    }

    private fun startTcpListener() {
        if (serverSocket != null && !serverSocket!!.isClosed) return
        try {
            serverSocket = ServerSocket(TCP_PORT)
            Log.d(TAG, "TCP Server listener started on port $TCP_PORT")
            while (serviceScope.isActive && clientSocket == null) {
                val socket = serverSocket?.accept() ?: break
                if (_connectionState.value !is ConnectionState.Connected) {
                    handleSuccessfulConnection(socket, isHost = true)
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "TCP listener stopped: ${e.message}")
        }
    }

    // Continuously sends UDP Beacons to local router network every 3 seconds
    private fun startBeaconBroadcaster() {
        serviceScope.launch(Dispatchers.IO) {
            while (serviceScope.isActive) {
                try {
                    val localIp = WifiUtils.getLocalIpAddress()
                    if (localIp != "127.0.0.1" && localIp.contains(".")) {
                        val deviceName = WifiUtils.getDeviceName()
                        val phoneModel = android.os.Build.MODEL ?: "Android Device"
                        val androidVer = android.os.Build.VERSION.RELEASE ?: "Android"
                        val statusStr = getMyUserStatus().name

                        // Handshake payload format
                        val payload = "BEACON|$HANDSHAKE_TOKEN|$myDeviceId|$deviceName|$phoneModel|$androidVer|$localIp|1.0.0|$statusStr"
                        val data = payload.toByteArray(Charsets.UTF_8)

                        val socket = DatagramSocket()
                        socket.broadcast = true

                        // 1. Broadcast address
                        val bAddr = InetAddress.getByName(WifiUtils.getBroadcastAddress())
                        socket.send(DatagramPacket(data, data.size, bAddr, UDP_PORT))

                        // 2. Global broadcast
                        val gAddr = InetAddress.getByName("255.255.255.255")
                        socket.send(DatagramPacket(data, data.size, gAddr, UDP_PORT))

                        socket.close()
                    }
                } catch (e: Exception) {
                    Log.d(TAG, "Beacon broadcast note: ${e.message}")
                }
                delay(3000)
            }
        }
    }

    // Continuously listens for incoming UDP Beacons from app instances on the router
    private fun startBeaconReceiver() {
        serviceScope.launch(Dispatchers.IO) {
            try {
                udpBeaconSocket?.close()
                udpBeaconSocket = DatagramSocket(UDP_PORT)
                val buffer = ByteArray(2048)

                while (serviceScope.isActive) {
                    val packet = DatagramPacket(buffer, buffer.size)
                    udpBeaconSocket?.receive(packet)

                    val message = String(packet.data, 0, packet.length).trim()
                    if (message.startsWith("BEACON|$HANDSHAKE_TOKEN|")) {
                        val parts = message.split("|")
                        if (parts.size >= 9) {
                            val devId = parts[2]
                            val devName = parts[3]
                            val pModel = parts[4]
                            val androidV = parts[5]
                            val hostIp = parts[6]
                            val appVer = parts[7]
                            val statusStr = parts[8]

                            val localIp = WifiUtils.getLocalIpAddress()
                            if (hostIp != localIp) { // Don't add self
                                val status = try { UserStatus.valueOf(statusStr) } catch (e: Exception) { UserStatus.ONLINE }
                                val isFav = favoriteIps.contains(hostIp)

                                val host = WifiHostDomain(
                                    deviceId = devId,
                                    name = devName,
                                    phoneModel = pModel,
                                    androidVersion = androidV,
                                    ipAddress = hostIp,
                                    port = TCP_PORT,
                                    appVersion = appVer,
                                    status = status,
                                    isFavorite = isFav,
                                    lastSeenTimestamp = System.currentTimeMillis()
                                )

                                updateDiscoveredHost(host)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.d(TAG, "Beacon receiver closed: ${e.message}")
            }
        }
    }

    private fun updateDiscoveredHost(host: WifiHostDomain) {
        val current = _discoveredHosts.value.toMutableList()
        val index = current.indexOfFirst { it.ipAddress == host.ipAddress }
        if (index >= 0) {
            current[index] = host.copy(isFavorite = favoriteIps.contains(host.ipAddress))
        } else {
            current.add(host.copy(isFavorite = favoriteIps.contains(host.ipAddress)))
        }
        // Sort: Favorites first, then Online, then Name
        _discoveredHosts.value = sortHosts(current)
    }

    private fun sortHosts(hosts: List<WifiHostDomain>): List<WifiHostDomain> {
        return hosts.sortedWith(
            compareByDescending<WifiHostDomain> { it.isFavorite }
                .thenBy { it.status == UserStatus.OFFLINE }
                .thenBy { it.name }
        )
    }

    // Cleans up devices that haven't sent a beacon in >10 seconds
    private fun startCleanupTask() {
        serviceScope.launch(Dispatchers.IO) {
            while (serviceScope.isActive) {
                delay(4000)
                val now = System.currentTimeMillis()
                val current = _discoveredHosts.value.toMutableList()
                var updated = false

                val iterator = current.iterator()
                while (iterator.hasNext()) {
                    val host = iterator.next()
                    val diff = now - host.lastSeenTimestamp
                    if (diff > 15000) { // Removed if no beacon for 15s
                        iterator.remove()
                        updated = true
                    } else if (diff > 10000 && host.status != UserStatus.OFFLINE) { // Mark offline if >10s
                        val idx = current.indexOf(host)
                        if (idx >= 0) {
                            current[idx] = host.copy(status = UserStatus.OFFLINE)
                            updated = true
                        }
                    }
                }

                if (updated) {
                    _discoveredHosts.value = sortHosts(current)
                }
            }
        }
    }

    fun toggleFavorite(hostIp: String) {
        if (favoriteIps.contains(hostIp)) {
            favoriteIps.remove(hostIp)
        } else {
            favoriteIps.add(hostIp)
        }
        _discoveredHosts.value = sortHosts(_discoveredHosts.value.map {
            if (it.ipAddress == hostIp) it.copy(isFavorite = favoriteIps.contains(hostIp)) else it
        })
    }

    override fun startHost() {
        if (_connectionState.value is ConnectionState.Connected) return
        _connectionState.value = ConnectionState.Listening
        startBackgroundService()
    }

    override fun connectToDevice(addressOrIp: String, name: String?) {
        stopAllSockets()
        val targetIp = addressOrIp.trim()
        val targetName = name ?: "جهاز Wi-Fi ($targetIp)"

        _connectionState.value = ConnectionState.Connecting(targetName)
        lastConnectedIp = targetIp
        lastConnectedName = targetName
        shouldAutoReconnect = true

        serviceScope.launch(Dispatchers.IO) {
            try {
                val socket = Socket(targetIp, TCP_PORT)
                handleSuccessfulConnection(socket, isHost = false, overrideName = targetName)
            } catch (e: Exception) {
                Log.e(TAG, "TCP connection error to $targetIp: ${e.message}")
                _connectionState.value = ConnectionState.Error("فشل الاتصال بالـ IP ($targetIp)")
                triggerAutoReconnect()
            }
        }
    }

    fun startAutoDiscovery() {
        _isDiscovering.value = true
        serviceScope.launch(Dispatchers.IO) {
            try {
                // Immediate ARP & Subnet probe sweep to detect devices fast
                val localIp = WifiUtils.getLocalIpAddress()
                if (localIp != "127.0.0.1" && localIp.contains(".")) {
                    val prefix = localIp.substringBeforeLast(".") + "."
                    (1..254).map { i ->
                        async {
                            val ip = "$prefix$i"
                            if (ip != localIp) {
                                try {
                                    val socket = Socket()
                                    socket.connect(InetSocketAddress(ip, TCP_PORT), 200)
                                    socket.close()
                                } catch (ignored: Exception) {}
                            }
                        }
                    }.awaitAll()
                }
            } catch (e: Exception) {
                Log.d(TAG, "Fast probe done")
            } finally {
                delay(1000)
                _isDiscovering.value = false
            }
        }
    }

    private fun handleSuccessfulConnection(
        socket: Socket,
        isHost: Boolean,
        overrideName: String? = null
    ) {
        clientSocket = socket
        val remoteIp = socket.inetAddress.hostAddress ?: "127.0.0.1"
        val remoteName = overrideName ?: "جهاز Wi-Fi ($remoteIp)"

        val deviceDomain = BluetoothDeviceDomain(
            name = remoteName,
            address = remoteIp
        )

        lastConnectedIp = remoteIp
        lastConnectedName = remoteName
        shouldAutoReconnect = true

        _connectionState.value = ConnectionState.Connected(
            device = deviceDomain,
            connectionType = ConnectionType.WIFI_LAN,
            ipAddress = remoteIp,
            port = TCP_PORT
        )

        serviceScope.launch(Dispatchers.IO) {
            try {
                val inputStream = socket.getInputStream()
                outputStream = socket.getOutputStream()
                val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))

                while (isActive && socket.isConnected && !socket.isClosed) {
                    val line = reader.readLine() ?: break
                    if (line.isNotBlank()) {
                        val pkt = BluetoothPacket.fromJsonString(line)
                        if (pkt != null) {
                            when (pkt.type) {
                                PacketType.TYPING_START -> _isPartnerTyping.value = true
                                PacketType.TYPING_STOP -> _isPartnerTyping.value = false
                                PacketType.CHAT -> {
                                    _isPartnerTyping.value = false
                                    sendAck(pkt.id)
                                    _receivedPackets.emit(pkt)
                                }
                                PacketType.ACK, PacketType.CONNECT_REQUEST, PacketType.CONNECT_RESPONSE -> {
                                    _receivedPackets.emit(pkt)
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "TCP read error: ${e.message}")
            } finally {
                Log.d(TAG, "Wi-Fi TCP connection closed")
                _connectionState.value = ConnectionState.Disconnected
                _isPartnerTyping.value = false
                triggerAutoReconnect()
            }
        }
    }

    override fun sendChatMessage(id: String, text: String): Boolean {
        if (!isConnected()) return false
        val packet = BluetoothPacket(
            type = PacketType.CHAT,
            id = id,
            senderAddress = WifiUtils.getLocalIpAddress(),
            senderName = WifiUtils.getDeviceName(),
            senderPhoneModel = android.os.Build.MODEL ?: "Android",
            text = text,
            timestamp = System.currentTimeMillis()
        )
        return sendPacketInternal(packet)
    }

    override fun sendPacket(packet: BluetoothPacket): Boolean {
        return sendPacketInternal(packet)
    }

    private fun sendAck(ackMessageId: String) {
        val packet = BluetoothPacket(
            type = PacketType.ACK,
            senderAddress = WifiUtils.getLocalIpAddress(),
            senderName = WifiUtils.getDeviceName(),
            ackMessageId = ackMessageId
        )
        sendPacketInternal(packet)
    }

    override fun sendTypingStatus(isTyping: Boolean) {
        if (!isConnected()) return
        val packet = BluetoothPacket(
            type = if (isTyping) PacketType.TYPING_START else PacketType.TYPING_STOP,
            senderAddress = WifiUtils.getLocalIpAddress(),
            senderName = WifiUtils.getDeviceName()
        )
        sendPacketInternal(packet)
    }

    private fun sendPacketInternal(packet: BluetoothPacket): Boolean {
        return try {
            val jsonLine = packet.toJsonString() + "\n"
            synchronized(this) {
                outputStream?.write(jsonLine.toByteArray(Charsets.UTF_8))
                outputStream?.flush()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send packet over Wi-Fi: ${e.message}")
            disconnect()
            false
        }
    }

    override fun isConnected(): Boolean {
        return _connectionState.value is ConnectionState.Connected && clientSocket?.isConnected == true
    }

    override fun reconnect() {
        val lastIp = lastConnectedIp
        if (lastIp != null) {
            connectToDevice(lastIp, lastConnectedName)
        } else {
            startHost()
        }
    }

    private fun triggerAutoReconnect() {
        if (!shouldAutoReconnect || lastConnectedIp == null) return

        serviceScope.launch {
            delay(3000)
            if (_connectionState.value is ConnectionState.Disconnected && shouldAutoReconnect) {
                lastConnectedIp?.let { ip ->
                    connectToDevice(ip, lastConnectedName)
                }
            }
        }
    }

    override fun disconnect() {
        shouldAutoReconnect = false
        stopAllSockets()
        _connectionState.value = ConnectionState.Disconnected
        _isPartnerTyping.value = false
    }

    private fun stopAllSockets() {
        try {
            clientSocket?.close()
            clientSocket = null

            outputStream = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping sockets: ${e.message}")
        }
    }

    override fun onDestroy() {
        disconnect()
        try {
            serverSocket?.close()
            udpBeaconSocket?.close()
        } catch (ignored: Exception) {}
    }
}
