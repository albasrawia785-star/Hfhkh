package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.ui.components.ConnectionRequestDialog
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.ConversationsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ModeSelectionScreen
import com.example.ui.screens.ScanScreen
import com.example.ui.screens.WifiScanScreen
import com.example.viewmodel.ChatViewModel

@Composable
fun NavGraph(
    navController: NavHostController,
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val incomingRequest by viewModel.incomingRequest.collectAsStateWithLifecycle()

    ConnectionRequestDialog(
        request = incomingRequest,
        onAccept = { request ->
            viewModel.acceptConnectionRequest(request)
            navController.navigate(Screen.Chat.route) {
                popUpTo(Screen.ModeSelection.route)
            }
        },
        onDecline = { request ->
            viewModel.declineConnectionRequest(request)
        }
    )

    NavHost(
        navController = navController,
        startDestination = Screen.ModeSelection.route,
        modifier = modifier
    ) {
        composable(Screen.ModeSelection.route) {
            ModeSelectionScreen(
                viewModel = viewModel,
                onSelectBluetooth = {
                    navController.navigate(Screen.Home.route)
                },
                onSelectWifi = {
                    navController.navigate(Screen.WifiScan.route)
                },
                onNavigateToConversations = {
                    navController.navigate(Screen.Conversations.route)
                }
            )
        }

        composable(Screen.Conversations.route) {
            ConversationsScreen(
                viewModel = viewModel,
                onNavigateToHost = {
                    navController.navigate(Screen.ModeSelection.route)
                },
                onNavigateToScan = {
                    navController.navigate(Screen.Scan.route)
                },
                onNavigateToChat = {
                    navController.navigate(Screen.Chat.route)
                }
            )
        }

        composable(Screen.Home.route) {
            HomeScreen(
                viewModel = viewModel,
                onNavigateToScan = {
                    navController.navigate(Screen.Scan.route)
                },
                onNavigateToChat = {
                    navController.navigate(Screen.Chat.route) {
                        popUpTo(Screen.ModeSelection.route)
                    }
                }
            )
        }

        composable(Screen.WifiScan.route) {
            WifiScanScreen(
                viewModel = viewModel,
                onBackClick = {
                    navController.popBackStack()
                },
                onNavigateToChat = {
                    navController.navigate(Screen.Chat.route) {
                        popUpTo(Screen.ModeSelection.route)
                    }
                }
            )
        }

        composable(Screen.Scan.route) {
            ScanScreen(
                viewModel = viewModel,
                onBackClick = {
                    navController.popBackStack()
                },
                onNavigateToChat = {
                    navController.navigate(Screen.Chat.route) {
                        popUpTo(Screen.ModeSelection.route)
                    }
                }
            )
        }

        composable(Screen.Chat.route) {
            ChatScreen(
                viewModel = viewModel,
                onBackClick = {
                    navController.popBackStack()
                }
            )
        }
    }
}
