package com.example.connection

import android.content.Context
import com.example.bluetooth.BluetoothService
import com.example.model.BluetoothDeviceDomain
import com.example.model.BluetoothPacket
import com.example.model.ConnectionRequest
import com.example.model.ConnectionState
import com.example.model.ConnectionType
import com.example.model.OutgoingRequestStatus
import com.example.model.PacketType
import com.example.model.WifiHostDomain
import com.example.utils.WifiNotificationManager
import com.example.wifi.WifiService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ConnectionManager(
    private val context: Context,
    val bluetoothService: BluetoothService,
    val wifiService: WifiService
) {
    private val notificationManager = WifiNotificationManager(context)

    private val _connectionType = MutableStateFlow(ConnectionType.WIFI_LAN)
    val connectionType: StateFlow<ConnectionType> = _connectionType.asStateFlow()

    private val managerScope = CoroutineScope(Dispatchers.IO + Job())

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _receivedPackets = MutableSharedFlow<BluetoothPacket>(extraBufferCapacity = 128)
    val receivedPackets: SharedFlow<BluetoothPacket> = _receivedPackets.asSharedFlow()

    private val _isPartnerTyping = MutableStateFlow(false)
    val isPartnerTyping: StateFlow<Boolean> = _isPartnerTyping.asStateFlow()

    private val _incomingRequest = MutableStateFlow<ConnectionRequest?>(null)
    val incomingRequest: StateFlow<ConnectionRequest?> = _incomingRequest.asStateFlow()

    private val _outgoingRequestStatus = MutableStateFlow(OutgoingRequestStatus.NONE)
    val outgoingRequestStatus: StateFlow<OutgoingRequestStatus> = _outgoingRequestStatus.asStateFlow()

    private var outgoingTimeoutJob: Job? = null
    private var incomingTimeoutJob: Job? = null

    init {
        // Collect Bluetooth packets
        managerScope.launch {
            bluetoothService.receivedPackets.collect { packet ->
                handleIncomingPacket(packet, ConnectionType.BLUETOOTH)
            }
        }

        // Collect Wi-Fi packets
        managerScope.launch {
            wifiService.receivedPackets.collect { packet ->
                handleIncomingPacket(packet, ConnectionType.WIFI_LAN)
            }
        }

        // Collect Bluetooth State
        managerScope.launch {
            bluetoothService.connectionState.collect { state ->
                if (_connectionType.value == ConnectionType.BLUETOOTH) {
                    _connectionState.value = state
                }
            }
        }

        // Collect Wi-Fi State
        managerScope.launch {
            wifiService.connectionState.collect { state ->
                if (_connectionType.value == ConnectionType.WIFI_LAN) {
                    _connectionState.value = state
                }
            }
        }

        // Collect Bluetooth Typing
        managerScope.launch {
            bluetoothService.isPartnerTyping.collect { isTyping ->
                if (_connectionType.value == ConnectionType.BLUETOOTH) {
                    _isPartnerTyping.value = isTyping
                }
            }
        }

        // Collect Wi-Fi Typing
        managerScope.launch {
            wifiService.isPartnerTyping.collect { isTyping ->
                if (_connectionType.value == ConnectionType.WIFI_LAN) {
                    _isPartnerTyping.value = isTyping
                }
            }
        }
    }

    private suspend fun handleIncomingPacket(packet: BluetoothPacket, type: ConnectionType) {
        if (_connectionType.value != type) return

        when (packet.type) {
            PacketType.CONNECT_REQUEST -> {
                // Check if user is already busy in an active chat
                if (connectionState.value is ConnectionState.Connected) {
                    // Auto decline with BUSY status
                    val busyPacket = BluetoothPacket(
                        type = PacketType.CONNECT_RESPONSE,
                        senderAddress = getMyAddress(),
                        senderName = getMyName(),
                        text = "BUSY"
                    )
                    getActiveConnection().sendPacket(busyPacket)
                    return
                }

                // Show notification if app in background or minimized
                notificationManager.showConnectionRequestNotification(
                    senderName = packet.senderName,
                    phoneModel = packet.senderPhoneModel
                )

                val req = ConnectionRequest(
                    senderId = packet.id,
                    senderName = packet.senderName,
                    senderPhoneModel = packet.senderPhoneModel,
                    senderAddress = packet.senderAddress,
                    connectionType = type
                )
                _incomingRequest.value = req

                // Launch 30-Second Receiver Timeout Job
                incomingTimeoutJob?.cancel()
                incomingTimeoutJob = managerScope.launch {
                    delay(30000)
                    if (_incomingRequest.value == req) {
                        _incomingRequest.value = null
                        val expirePacket = BluetoothPacket(
                            type = PacketType.CONNECT_RESPONSE,
                            senderAddress = getMyAddress(),
                            senderName = getMyName(),
                            text = "EXPIRED"
                        )
                        getActiveConnection().sendPacket(expirePacket)
                    }
                }
            }
            PacketType.CONNECT_RESPONSE -> {
                outgoingTimeoutJob?.cancel()
                when (packet.text) {
                    "ACCEPTED" -> {
                        _outgoingRequestStatus.value = OutgoingRequestStatus.ACCEPTED
                    }
                    "DECLINED" -> {
                        _outgoingRequestStatus.value = OutgoingRequestStatus.DECLINED
                        disconnect()
                    }
                    "BUSY" -> {
                        _outgoingRequestStatus.value = OutgoingRequestStatus.BUSY
                        disconnect()
                    }
                    "EXPIRED" -> {
                        _outgoingRequestStatus.value = OutgoingRequestStatus.EXPIRED
                        disconnect()
                    }
                    else -> {
                        _outgoingRequestStatus.value = OutgoingRequestStatus.DECLINED
                        disconnect()
                    }
                }
            }
            else -> {
                _receivedPackets.emit(packet)
            }
        }
    }

    fun sendConnectionRequest(addressOrIp: String, name: String? = null, phoneModel: String? = null) {
        outgoingTimeoutJob?.cancel()
        managerScope.launch {
            _outgoingRequestStatus.value = OutgoingRequestStatus.WAITING
            connectToDevice(addressOrIp, name)

            // Wait up to 10s to establish socket
            val startTime = System.currentTimeMillis()
            while (connectionState.value !is ConnectionState.Connected && System.currentTimeMillis() - startTime < 10000) {
                delay(200)
            }

            if (connectionState.value is ConnectionState.Connected) {
                val packet = BluetoothPacket(
                    type = PacketType.CONNECT_REQUEST,
                    senderAddress = getMyAddress(),
                    senderName = getMyName(),
                    senderPhoneModel = android.os.Build.MODEL ?: "Android Device"
                )
                getActiveConnection().sendPacket(packet)

                // Launch 30-Second Sender Timeout Timer
                outgoingTimeoutJob = managerScope.launch {
                    delay(30000)
                    if (_outgoingRequestStatus.value == OutgoingRequestStatus.WAITING) {
                        _outgoingRequestStatus.value = OutgoingRequestStatus.EXPIRED
                        disconnect()
                    }
                }
            } else {
                _outgoingRequestStatus.value = OutgoingRequestStatus.NONE
            }
        }
    }

    fun acceptRequest(request: ConnectionRequest) {
        incomingTimeoutJob?.cancel()
        notificationManager.cancelNotification()
        managerScope.launch {
            val packet = BluetoothPacket(
                type = PacketType.CONNECT_RESPONSE,
                senderAddress = getMyAddress(),
                senderName = getMyName(),
                text = "ACCEPTED"
            )
            getActiveConnection().sendPacket(packet)
            _incomingRequest.value = null
        }
    }

    fun declineRequest(request: ConnectionRequest) {
        incomingTimeoutJob?.cancel()
        notificationManager.cancelNotification()
        managerScope.launch {
            val packet = BluetoothPacket(
                type = PacketType.CONNECT_RESPONSE,
                senderAddress = getMyAddress(),
                senderName = getMyName(),
                text = "DECLINED"
            )
            getActiveConnection().sendPacket(packet)
            _incomingRequest.value = null
            disconnect()
        }
    }

    fun resetOutgoingRequestStatus() {
        outgoingTimeoutJob?.cancel()
        _outgoingRequestStatus.value = OutgoingRequestStatus.NONE
    }

    fun setConnectionType(type: ConnectionType) {
        if (_connectionType.value != type) {
            getActiveConnection().disconnect()
            _connectionType.value = type
            _connectionState.value = ConnectionState.Disconnected
            _isPartnerTyping.value = false
        }
    }

    fun getActiveConnection(): ChatConnection {
        return when (_connectionType.value) {
            ConnectionType.BLUETOOTH -> bluetoothService
            ConnectionType.WIFI_LAN -> wifiService
        }
    }

    fun startHost() {
        getActiveConnection().startHost()
    }

    fun connectToDevice(addressOrIp: String, name: String? = null) {
        getActiveConnection().connectToDevice(addressOrIp, name)
    }

    fun connectToBluetoothDevice(deviceDomain: BluetoothDeviceDomain) {
        setConnectionType(ConnectionType.BLUETOOTH)
        bluetoothService.connectToDevice(deviceDomain)
    }

    fun sendChatMessage(id: String, text: String): Boolean {
        return getActiveConnection().sendChatMessage(id, text)
    }

    fun sendTypingStatus(isTyping: Boolean) {
        getActiveConnection().sendTypingStatus(isTyping)
    }

    fun reconnect() {
        getActiveConnection().reconnect()
    }

    fun disconnect() {
        getActiveConnection().disconnect()
    }

    fun getMyAddress(): String {
        return when (_connectionType.value) {
            ConnectionType.BLUETOOTH -> bluetoothService.bluetoothManager.getMyDeviceAddress()
            ConnectionType.WIFI_LAN -> com.example.utils.WifiUtils.getLocalIpAddress()
        }
    }

    fun getMyName(): String {
        return when (_connectionType.value) {
            ConnectionType.BLUETOOTH -> bluetoothService.bluetoothManager.getMyDeviceName()
            ConnectionType.WIFI_LAN -> com.example.utils.WifiUtils.getDeviceName()
        }
    }

    fun onDestroy() {
        bluetoothService.onDestroy()
        wifiService.onDestroy()
    }
}
