package com.example.connection

import com.example.model.BluetoothPacket
import com.example.model.ConnectionState
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

interface ChatConnection {
    val connectionState: StateFlow<ConnectionState>
    val receivedPackets: SharedFlow<BluetoothPacket>
    val isPartnerTyping: StateFlow<Boolean>

    fun startHost()
    fun connectToDevice(addressOrIp: String, name: String? = null)
    fun disconnect()
    fun sendChatMessage(id: String, text: String): Boolean
    fun sendPacket(packet: BluetoothPacket): Boolean
    fun sendTypingStatus(isTyping: Boolean)
    fun isConnected(): Boolean
    fun reconnect()
    fun onDestroy()
}
