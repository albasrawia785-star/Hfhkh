package com.example.data.repository

import android.content.Context
import com.example.bluetooth.BluetoothService
import com.example.connection.ConnectionManager
import com.example.data.database.ChatMessageDao
import com.example.data.database.ChatMessageEntity
import com.example.model.BluetoothDeviceDomain
import com.example.model.ConnectionState
import com.example.model.ConnectionType
import com.example.model.ConversationSummary
import com.example.model.PacketType
import com.example.model.WifiHostDomain
import com.example.utils.NotificationHelper
import com.example.wifi.WifiService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.UUID

class ChatRepository(
    private val context: Context,
    private val dao: ChatMessageDao,
    val connectionManager: ConnectionManager
) {
    private val repoScope = CoroutineScope(Dispatchers.IO + Job())

    val bluetoothService: BluetoothService get() = connectionManager.bluetoothService
    val wifiService: WifiService get() = connectionManager.wifiService

    val connectionState: StateFlow<ConnectionState> = connectionManager.connectionState
    val activeConnectionType: StateFlow<ConnectionType> = connectionManager.connectionType

    val scannedDevices: StateFlow<List<BluetoothDeviceDomain>> = bluetoothService.bluetoothManager.scannedDevices
    val isScanning: StateFlow<Boolean> = bluetoothService.bluetoothManager.isScanning
    val isBluetoothEnabled: StateFlow<Boolean> = bluetoothService.bluetoothManager.isBluetoothEnabled
    val isPartnerTyping: StateFlow<Boolean> = connectionManager.isPartnerTyping

    val discoveredWifiHosts: StateFlow<List<WifiHostDomain>> = wifiService.discoveredHosts
    val isWifiDiscovering: StateFlow<Boolean> = wifiService.isDiscovering

    val incomingRequest: StateFlow<com.example.model.ConnectionRequest?> = connectionManager.incomingRequest
    val outgoingRequestStatus: StateFlow<com.example.model.OutgoingRequestStatus> = connectionManager.outgoingRequestStatus

    fun sendWifiConnectionRequest(ipAddress: String, name: String? = null) {
        connectionManager.setConnectionType(ConnectionType.WIFI_LAN)
        connectionManager.sendConnectionRequest(ipAddress, name)
    }

    fun acceptConnectionRequest(request: com.example.model.ConnectionRequest) {
        connectionManager.acceptRequest(request)
    }

    fun declineConnectionRequest(request: com.example.model.ConnectionRequest) {
        connectionManager.declineRequest(request)
    }

    fun resetOutgoingRequestStatus() {
        connectionManager.resetOutgoingRequestStatus()
    }

    private val _activeChatPartnerAddress = MutableStateFlow("")
    val activeChatPartnerAddress: StateFlow<String> = _activeChatPartnerAddress.asStateFlow()

    init {
        NotificationHelper.createNotificationChannel(context)

        // Observe incoming packets from ConnectionManager
        repoScope.launch {
            connectionManager.receivedPackets.collect { packet ->
                when (packet.type) {
                    PacketType.CHAT -> {
                        val activePartner = _activeChatPartnerAddress.value
                        val isCurrentChatActive = (activePartner == packet.senderAddress)

                        val entity = ChatMessageEntity(
                            id = packet.id,
                            senderAddress = packet.senderAddress,
                            senderName = packet.senderName,
                            text = packet.text,
                            timestamp = packet.timestamp,
                            isFromMe = false,
                            isDelivered = true,
                            isRead = isCurrentChatActive,
                            chatPartnerAddress = packet.senderAddress
                        )
                        dao.insertMessage(entity)

                        if (!isCurrentChatActive) {
                            NotificationHelper.showMessageNotification(
                                context = context,
                                senderName = packet.senderName,
                                messageText = packet.text
                            )
                        }
                    }
                    PacketType.ACK -> {
                        if (packet.ackMessageId.isNotBlank()) {
                            dao.markMessageDelivered(packet.ackMessageId)
                        }
                    }
                    else -> {}
                }
            }
        }
    }

    fun setConnectionType(type: ConnectionType) {
        connectionManager.setConnectionType(type)
    }

    fun setActiveChatPartner(partnerAddress: String) {
        _activeChatPartnerAddress.value = partnerAddress
        if (partnerAddress.isNotBlank()) {
            repoScope.launch {
                dao.markMessagesAsReadForPartner(partnerAddress)
            }
        }
    }

    val conversations: Flow<List<ConversationSummary>> = dao.getAllMessages().map { allMsgs ->
        allMsgs.groupBy { it.chatPartnerAddress }
            .map { (partnerAddress, msgs) ->
                val lastMsg = msgs.maxByOrNull { it.timestamp }!!
                val partnerName = msgs.firstOrNull { !it.isFromMe && it.senderName.isNotBlank() }?.senderName
                    ?: lastMsg.senderName.ifBlank { partnerAddress }
                val unreadCount = msgs.count { !it.isFromMe && !it.isRead }

                ConversationSummary(
                    partnerAddress = partnerAddress,
                    partnerName = partnerName,
                    lastMessageText = lastMsg.text,
                    lastMessageTimestamp = lastMsg.timestamp,
                    unreadCount = unreadCount
                )
            }
            .sortedByDescending { it.lastMessageTimestamp }
    }

    fun getMessagesForPartner(partnerAddress: String): Flow<List<ChatMessageEntity>> {
        return dao.getMessagesForPartner(partnerAddress)
    }

    suspend fun sendMessage(text: String, partnerAddress: String, partnerName: String): Boolean {
        val messageId = UUID.randomUUID().toString()
        val timestamp = System.currentTimeMillis()

        val myAddress = connectionManager.getMyAddress()
        val myName = connectionManager.getMyName()

        val entity = ChatMessageEntity(
            id = messageId,
            senderAddress = myAddress,
            senderName = myName,
            text = text,
            timestamp = timestamp,
            isFromMe = true,
            isDelivered = false,
            isRead = true,
            chatPartnerAddress = partnerAddress.ifBlank { "UNKNOWN_DEVICE" }
        )

        dao.insertMessage(entity)

        val success = connectionManager.sendChatMessage(id = messageId, text = text)
        return success
    }

    fun sendTypingStatus(isTyping: Boolean) {
        connectionManager.sendTypingStatus(isTyping)
    }

    fun startHost() {
        connectionManager.startHost()
    }

    fun connectToDevice(device: BluetoothDeviceDomain) {
        connectionManager.connectToBluetoothDevice(device)
    }

    fun connectToWifiHost(ipAddress: String, name: String? = null) {
        connectionManager.setConnectionType(ConnectionType.WIFI_LAN)
        connectionManager.connectToDevice(ipAddress, name)
    }

    fun toggleFavoriteHost(ipAddress: String) {
        wifiService.toggleFavorite(ipAddress)
    }

    fun startWifiDiscovery() {
        wifiService.startAutoDiscovery()
    }

    fun startScan() {
        bluetoothService.bluetoothManager.startDiscovery()
    }

    fun stopScan() {
        bluetoothService.bluetoothManager.stopDiscovery()
    }

    fun getPairedDevices(): List<BluetoothDeviceDomain> {
        return bluetoothService.bluetoothManager.getPairedDevices()
    }

    fun reconnect() {
        connectionManager.reconnect()
    }

    fun disconnect() {
        connectionManager.disconnect()
    }

    suspend fun clearHistory(partnerAddress: String) {
        dao.clearMessagesForPartner(partnerAddress)
    }

    suspend fun clearAllHistory() {
        dao.clearAllMessages()
    }
}
